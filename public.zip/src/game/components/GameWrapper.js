import styled from 'styled-components';

export const GameWrapper = styled.div`
    display: flex;
    flex-direction: row;
`;
