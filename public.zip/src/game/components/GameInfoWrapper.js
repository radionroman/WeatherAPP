import styled from 'styled-components';

export const GameInfoWrapper = styled.div`
    margin-left: ${({ theme }) => theme.dims.bigSpacing};
`;
