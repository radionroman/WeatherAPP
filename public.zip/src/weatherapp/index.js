import { Map } from "./components";

export const WeatherApp = () => <Map />;
