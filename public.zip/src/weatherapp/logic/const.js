export const BBOX = {
  _southWest: {
    lat: 51.433697853299584,
    lng: -0.20874602733685027,
  },
  _northEast: {
    lat: 51.52200848380265,
    lng: 0.08960144580766106,
  },
};

export const CITIES = [{
  
  type: "node",
  id: 240109189,
  lat: 51.5073219,
  lon: -0.1276474,
  name: "London",
  place: "city",
  population: "8173941",

}];

export const WEATHER = [
  {
    coord: {
      lon: -0.1257,
      lat: 51.5085
    },
    name: "London",
    temp_c: 8.0,
    precip_mm: 0.0
    
  }
]