import { createSelector } from "@reduxjs/toolkit";
import { BBOX } from "./const";
import { MAP_LOGIC_REDUCER_NAME } from "./reducer";

export const selectMapState = (state) => state[MAP_LOGIC_REDUCER_NAME];

export const bboxSelector = createSelector(selectMapState, ({ bbox }) => bbox);

export const citiesSelector = createSelector(selectMapState, ({ overpassData }) => overpassData);

export const weatherSelector = createSelector(selectMapState, ({ weatherData }) => weatherData);

// export const citiesSelector = createSelector(selectMapState, ({ overpassData }) => overpassData);
// export const currentPlayerSelector = createSelector(
//   selectGameState,
//   ({ currentPlayer }) => currentPlayer
// );

// export const boardSizeSelector = createSelector(
//   selectGameState,
//   ({ boardSize }) => boardSize
// );

// export const winnerSelector = createSelector(
//   boardSelector,
//   boardSizeSelector,
//   (board, boardSize) => calculateWinner(board, boardSize)
// );

// export const isGameFinishedSelector = createSelector(
//   winnerSelector,
//   boardSelector,
//   (winner, board) =>
//     winner !== PLAYERS.UNKNOWN ||
//     board
//       .flat(Infinity)
//       .reduce(
//         (allTaken, currentField) =>
//           allTaken && currentField !== FIELD_VALUES.EMPTY,
//         true
//       )
// );
