import { createSlice, createAction} from "@reduxjs/toolkit";
import { useDispatch } from "react-redux";
import { BBOX, CITIES, WEATHER } from "./const";

export const MAP_LOGIC_REDUCER_NAME = "mapLogic";

const initialState = {
  bbox: BBOX,
  overpassData: CITIES,
  weatherData: WEATHER,
};

const mapLogicSlice = createSlice({
  name: MAP_LOGIC_REDUCER_NAME,
  initialState,
  reducers: {
    updateBBox: (state, { payload }) => {
      state.bbox._northEast.lat = payload.lat;
      state.bbox._northEast.lng = payload.lng;
      state.bbox._southWest.lat = payload.lat2;
      state.bbox._southWest.lng = payload.lng2;
      console.log("updateBBox", payload);
    },

    fetchOverpassDataSuccess: (state, {payload}) => {
      console.log("fetchOverpassDataSuccess", payload);
      const { elements } = payload;
      const cities = elements.map((element) => {
        const { tags, lat, lon } = element;
        console.log("Element:", tags["name:en"]);
        return {
          name: tags["name:en"] || tags.name || "Unknown",
          population: parseInt(tags.population, 10) || 0, // Convert to integer, default to 0 if conversion fails
          lat,
          lon,
        };
      });

      cities.sort((a, b) => b.population - a.population);
      console.log("Cities:", cities.slice(0, 20));
      state.overpassData = cities.slice(0, 20);



    },
    fetchOverpassDataError: (state, action) => {
      console.log("fetchOverpassDataError", action);
    },
    fetchWeatherDataError: (state, action) => {
      console.log("fetchWeatherDataError", action);
    },
    fetchWeatherDataSuccess: (state, action) => {
      console.log("fetchWeatherDataSuccess", action);

      const  city  = action.payload.location.name;
      const lat = action.payload.location.lat;
      const lon = action.payload.location.lon;
      const  temp_c  = action.payload.current.temp_c;
      const precip_mm = action.payload.current.precip_mm;

      console.log("weather data", state.weatherData);
      const index = state.weatherData.find((city1) => city1.name === city);
      if (index === undefined){
        state.weatherData.push({ name: city, temp_c: temp_c, coord: {lat: lat, lon: lon}, precip_mm: precip_mm});
        console.log("City not found", city);

      }
      else {
        index.temp_c = temp_c;
        index.precip_mm = precip_mm;
        

      }

    },
  },
});

export const fetchWeatherDataRequest = createAction(
  `${MAP_LOGIC_REDUCER_NAME}/fetchWeatherDataRequest`
);
export const fetchOverpassDataRequest = createAction(
  `${MAP_LOGIC_REDUCER_NAME}/fetchOverpassDataRequest`
);

export const { updateBBox, fetchOverpassDataError, fetchOverpassDataSuccess, fetchWeatherDataSuccess, fetchWeatherDataError } = mapLogicSlice.actions;

export const mapLogicReducer = mapLogicSlice.reducer;
