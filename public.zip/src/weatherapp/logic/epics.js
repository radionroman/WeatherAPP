import { ofType, combineEpics } from "redux-observable";
import { switchMap,mergeMap, map, catchError, take  } from "rxjs/operators";
import { from, Observable, scan, debounce, interval, forkJoin, of, combineLatest  } from "rxjs";
import axios from "axios";
import { useDispatch } from "react-redux";
import {
  updateBBox,
  fetchOverpassDataSuccess,
  fetchOverpassDataError,
  fetchWeatherDataSuccess,
  fetchWeatherDataError,
  fetchOverpassDataRequest,
  fetchWeatherDataRequest
} from "./reducer";
import { bboxSelector } from "./selectors";

const update$ = interval(3600000);

const api = axios.create({

  baseURL: "https://overpass-api.de",
  headers: {
    "Content-Type": "application/x-www-form-urlencoded"
  }
});

export function customFrom(requestConfig) {
  const obs = new Observable(subscriber => {
    const source = axios.CancelToken.source();
    console.log("customFrom", requestConfig);
    api({ requestConfig, cancelToken: source.token })
      .then(response => {
        subscriber.next(response);
        subscriber.complete();
      })
      .catch(error => {

        subscriber.error(error);
      });
    return () => {
      source.cancel();
    };
  });
  return obs;
}

update$.pipe().subscribe(() => {
  console.log("update$");
});


const fetchOverpassDataEpic = (action$, state$) =>
  action$.pipe(
    
    ofType(fetchOverpassDataRequest.type),
    scan(i => ++i, 1),
    debounce(i => interval(200 * i)),
    mergeMap( (action) => {
      
      const bbox = bboxSelector(state$.value);
      // Define your Overpass query
      const overpassQuery = `
        [out:json];
        node 
        [place="city"]
                (
                  ${bbox._southWest.lat},${bbox._southWest.lng},${bbox._northEast.lat},${bbox._northEast.lng}
                );
                out;
      `;
      console.log("Overpass Query:", overpassQuery);
      // Construct the URL for Overpass API
      // Use Axios to make the POST request

      return from(api.post('/api/interpreter',`${overpassQuery}`)).pipe(
        // Handle the response data as needed
        map((response) => {
          console.log("Overpass API Response:", response.data);

          // Dispatch a success action (or any other action if needed) 
          return fetchOverpassDataSuccess(response.data);
        }),
        // Handle the error if the request fails
        catchError((error) => {
          console.error("Overpass API Error:", error);

          // Dispatch an error action
          return fetchOverpassDataError(error);
        })
      );
    })
  );

  const fetchWeatherDataEpic = (action$, state$) =>
  action$.pipe(
    ofType("mapLogic/fetchWeatherDataRequest"),
    mergeMap((action) => { 
      const url = `http://api.weatherapi.com/v1/current.json?key=1f710cbc5491475bbda124119240602&q=${action.payload.lat},${action.payload.lon}&aqi=no`;
      if (action.payload.name === "Unknown") {
        return of(fetchWeatherDataError("Unknown city"));
      }
      return from(axios.get(url)).pipe
      (map((response) => {
        console.log("Weather API Response:", response.data);
      
        return fetchWeatherDataSuccess(response.data);})
      )}),
    catchError((error) => {
      console.error("Weather API Error:", error);
      return fetchWeatherDataError(error);
    })
  );

  
  
  // const fetchWeatherDataEpic = (action$, state$) =>
  // action$.pipe(
  //   ofType(fetchWeatherDataRequest.type),
  //   mergeMap((action) => {
  //     console.log("Action", action.payload);
  //     const stream = (action.payload.map((city) => {
  //       const url = `http://api.weatherapi.com/v1/current.json?key=1f710cbc5491475bbda124119240602&q=${city.name}&aqi=no`;
  //       console.log("City", city);
  //       return (from(axios.get(url)).pipe
  //       (map((response) => {
  //         console.log("Weather API Response:", response.data);
  //         return fetchWeatherDataSuccess(response.data);}))
  //       );
  //     }));
  //     console.log("Stream", stream);
  //     const whatever = combineLatest(stream);
  //     console.log("Whatever", of(stream));
  //     return of(stream);
  //       // catchError((error) => {
  //       //   console.error("Weather API Error:", error);
  //       //   return fetchOverpassDataError(error);
  //       // })
      
  //     }))



export const mapEpics = combineEpics(fetchOverpassDataEpic, fetchWeatherDataEpic);
