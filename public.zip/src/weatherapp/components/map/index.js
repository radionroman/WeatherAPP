import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import { useMap, useMapEvents } from "react-leaflet";
import { useDispatch, useSelector } from "react-redux";
import { updateBBox } from "../../logic/reducer";
import { fetchOverpassDataRequest, fetchWeatherDataRequest } from "../../logic/reducer";
import { bboxSelector, citiesSelector } from "../../logic/selectors";
import icon from 'leaflet/dist/images/marker-icon.png';

import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import L from 'leaflet';
import { WeatherMarker } from "./components"

function MyComponent() {
  const dispatch = useDispatch();
  const map = useMapEvents({
    moveend: () => {
      const { _northEast, _southWest } = map.getBounds();
      const { lat, lng } = _northEast;
      const lat2 = _southWest.lat;
      const lng2 = _southWest.lng;
      // console.log(updateBBox({lat, lng, lat2, lng2}));
      dispatch( updateBBox({lat, lng, lat2, lng2}) );
      dispatch( fetchOverpassDataRequest() );
      
    },
  });

  return null;
}
export const Map = () => {
  const cities = useSelector(citiesSelector);
  console.log("Cities from state:", cities);
  const dispatch = useDispatch();
  cities.map((city)=> (
    dispatch(fetchWeatherDataRequest(city))
  ));
  let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow
});

L.Marker.prototype.options.icon = DefaultIcon;
  return (
    <MapContainer
      center={[51.505, -0.09]}
      zoom={13}
      scrollWheelZoom={true}
      style={{ minHeight: "100vh", minWidth: "100vw" }}
    >
      <TileLayer
        attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <MyComponent />
      <WeatherMarker />

    </MapContainer>
  );
};
