export const dims = {
    smallSpacing: '4px',
    basicSpacing: '8px',
    bigSpacing: '16px',

    history: {
        width: '144px'
    }
};
